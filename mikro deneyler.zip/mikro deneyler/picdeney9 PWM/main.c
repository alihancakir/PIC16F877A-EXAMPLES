//POT BUZZER-LED
#include <main.h>
#use delay (clock=4M)
#use fast_io(a)
void main()
{
   setup_adc(adc_clock_div_32);
   setup_adc_ports(AN0);
   
   
   setup_timer_2(T2_DIV_BY_16,254,1);      //1,0 ms overflow, 1,0 ms interrupt

   setup_ccp1(CCP_PWM);
 
   while(TRUE)
   {
set_adc_channel(0);
  delay_us(20);

set_pwm1_duty(read_adc());
delay_ms(100);
   }}

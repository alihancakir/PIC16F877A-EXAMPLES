//deney 2 sa�dan sola 1 �ifre
#include <16F877A.h>
#fuses HS,NOWDT,NOPROTECT,NOLVP
#use delay(clock=4000000)
#define LCD_ENABLE_PIN  PIN_D0
#define LCD_RS_PIN      PIN_D1
#define LCD_RW_PIN      PIN_D2
#define LCD_DATA4       PIN_D4
#define LCD_DATA5       PIN_D5
#define LCD_DATA6       PIN_D6
#define LCD_DATA7       PIN_D7
#define button PIN_A0
#include <lcd.c>

void main() {
 set_tris_a(0x01); 
   char header[] = "Hosgeldiniz:      ";
   char name[] = "Osayi Samuel        ";
    int i, j;
    int count=0;
    lcd_init(); 
    int messageLength = 15;
      
   printf(lcd_putc,"Sifreyi Giriniz:");
  while(TRUE){
   
   if(input(button)==TRUE){
      delay_ms(25);
      count++;
      delay_ms(300);
      while(input(button));
     if(count==3){
       lcd_putc('\f');
         for (i = 0; i < messageLength*2; ++i) {
         lcd_putc('\f'); 
         for (j = 0; j < messageLength; ++j)
            lcd_putc(header[(j + i) % messageLength]); 
         lcd_gotoxy(1, 2); 
         for (j = 0; j < messageLength; ++j)
            lcd_putc(name[(j + i) % messageLength]); 
         delay_ms(300); 
}}}}}

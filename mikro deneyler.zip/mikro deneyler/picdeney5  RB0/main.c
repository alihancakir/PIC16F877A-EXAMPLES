//deney1 3sm buzzer kontrol�
#include <16F877A.h>
#use delay(clock = 4MHz)
#INT_EXT                                         // RB0 KESMES� TANIMLANDI
void ext_buzzer(void){
  clear_interrupt(INT_EXT);                      // FLAG TEM�ZLEND�-Kesme i�levindeki ilk ad�m, kesme bayra��n�n temizlenmesidir. 
     while(TRUE){                                            // B�ylece kesme i�levi s�rekli �a�r�lmaz ve bir kere �al���r.
  output_high(PIN_C7);
  output_high(PIN_C1);
  delay_ms(3000);
  output_low(PIN_C7);
  output_low(PIN_C1);
 delay_ms(3000);
     }}
void main(){
        
  output_low(PIN_C7);
  output_low(PIN_C1);
  clear_interrupt(INT_EXT);                      // FLAG TEM�ZLEND� 
  
  enable_interrupts(INT_EXT_H2L);                // INT RB0 KESMES� BAYRA�I KALDIRILDI �Z�N VER�LD�
                                            //Harici kesme izni verilir ve RB0 �zerindeki d��en kenar (HIGH'den LOW'a ge�i�) kesme tipi se�ilir. 
                                                // Yani RB0 pini, y�ksek seviyeden d���k seviyeye ge�ti�inde kesme tetiklenir.
   
  enable_interrupts(GLOBAL);                     // GLOBAL OALRAK BAYRAK KALDIRILDI �Z�N VER�LD�
  while(TRUE);                                   // SONSUZ D�NG� 
}

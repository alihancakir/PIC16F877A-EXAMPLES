//LCD 
#include <16f877.h>
#device adc=10
#fuses HS,NOWDT,NOPROTECT,NOBROWNOUT,NOLVP,NOPUT,NOWRT,NODEBUG,NOCPD
#use delay(clock=4000000)
#use fast_io(a)
#define LCD_ENABLE_PIN  PIN_D2  
#define LCD_RW_PIN      PIN_D1  
#define LCD_RS_PIN      PIN_D0                                                   
#define LCD_DATA4       PIN_D3                               
#define LCD_DATA5       PIN_D4                                
#define LCD_DATA6       PIN_D5                    
#define LCD_DATA7       PIN_D6 
#include <lcd.c>
float info;
float voltage;
void main()
{
set_tris_a(0x01);
set_tris_d(0x00);


setup_adc(adc_clock_div_32);
setup_adc_ports(AN0);
lcd_init();
set_adc_channel(0);
delay_us(20);

while(1)
{
info=read_adc();
voltage=(0.0048828125*info);
lcd_gotoxy(5,1);

printf(lcd_putc,"D:%fV",voltage);
lcd_gotoxy(5,2);
printf(lcd_putc,"A:%f",info);

   
}
}


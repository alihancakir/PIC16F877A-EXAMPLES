//deney 5 e� zamanl� 500ms kontrol
#include <16F877A.h> 
#use delay(clock=4000000) 
#INT_RTCC
int sayac=0;
void RTCC_isr(void){
sayac++;
if(sayac==125){
output_toggle(pin_c0);
}
}
void main(){
setup_timer_0(RTCC_INTERNAL|RTCC_DIV_16|RTCC_8_BIT);
enable_interrupts(INT_RTCC);
enable_interrupts(GLOBAL); 
output_low(pin_c0);

while(1){}



}


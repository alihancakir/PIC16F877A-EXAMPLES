//deney1
#include <16F877A.h>
#fuses HS, NOWDT, NOPROTECT, NOLVP
#use delay(clock=4000000)
int array[] = {PIN_B0,
PIN_B1,PIN_B2,PIN_B3,PIN_B4,PIN_B5,PIN_B6,PIN_B7};
void main(){
 int i;
 while(1){
 for(i = 0; i <=7; i++){
 output_high(array[i]);
 delay_ms(100); 
 }
 for(i = 0; i <=7; i++){
 output_low(array[i]);
 delay_ms(100); 
 }
 }
}

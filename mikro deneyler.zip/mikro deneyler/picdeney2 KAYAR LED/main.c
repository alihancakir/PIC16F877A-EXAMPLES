#include <16F877A.h>
#device PASS_STRINGS = IN_RAM
#fuses HS, NOWDT, NOPROTECT, NOLVP
#use delay(clock=4000000)

void main() {
   set_tris_b(0x00);  // B portunu ��k�� olarak ayarla
   output_b(0x00);    // B portunu ba�lang��ta s�f�r yap

   int i;
   int a=0;

   while (TRUE) {
    /*  for (i = 1; i <= 15; i++) {  //TEK ���N
         if(i%3==0){
         output_b(i);  
         delay_ms(500);
      }
      else if(i==1){
      output_b(i);
      }
      }
      delay_ms(500);
*/
    for (i = 1; i <= 16; i++) {     //��FT ���N
         if(i%2==0){
         a=a+2;
         output_b(a);  
         delay_ms(500);
      }
     
      }
      delay_ms(500);
      }
   }



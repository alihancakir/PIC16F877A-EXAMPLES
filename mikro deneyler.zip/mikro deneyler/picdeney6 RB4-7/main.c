#include <main.h>
#define BUTTON1 PIN_B4
#define BUTTON2 PIN_B5
#define BUTTON3 PIN_B6
#define BUTTON4 PIN_B7
#define LED_PIN PIN_D7
#define LED_PIN_2 PIN_D0

#INT_RB
void RB_isr(void) 
{
    delay_ms(50); // Debouncing i�in bir s�re bekle
    if(input_b() & 0b11110000)
    {
    while(1){
         output_low(LED_PIN_2);
        output_high(LED_PIN);
        delay_ms(3000); // 3 saniye boyunca lojik 1
        output_low(LED_PIN);
        output_high(LED_PIN_2);
        delay_ms(3000);
    }
    clear_interrupt(INT_RB); // Kesme bayra��n� temizle
    }}

void main() 
{
    set_tris_d(0x00); // RD7 pinini ��k�� olarak ayarla
    output_low(LED_PIN); // Ba�lang��ta LED'i kapat

    // RB portunu giri� olarak ayarla
    set_tris_b(0xFF); // RB4, RB5, RB6, RB7 giri� olarak ayarla

    // RB portunda de�i�iklik oldu�unda kesme olu�tur
    enable_interrupts(INT_RB);
    enable_interrupts(GLOBAL);

}



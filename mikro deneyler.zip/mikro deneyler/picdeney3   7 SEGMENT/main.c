//deney 3
#include <16f877a.h>
#fuses HS, NOWDT, NOPROTECT, NOLVP
#use delay(clock=4000000)
int loop;
int i = 1;
int condition=(i + 1)%2==0;
const int array[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7C, 0x07, 0x7F, 0x6F}; 
void main(void)
{
    set_tris_b(0x00);  
    output_b(0x00);    
    while (TRUE)
    {
        for (loop = 0; loop < 5; loop++) 
        {
            output_b(array[i]);
            delay_ms(200);
            i = condition ? i+2 :i+1 ;     //i = (i + 2) % 10;    
        }
        i=1;
    }
}


#include <16F877A.h>
#fuses HS, NOWDT, NOPROTECT, NOLVP
#use delay(clock=4000000)



int i,condition;


void main() {
    
   set_tris_b(0x00);  //B PORTLARINI �IKI� YAPTIM

   output_b(0x00);    //B PORTLARI ���N �IKI� 0

   while(TRUE) {
    condition=1;
    for(i=0;i<8;i++){
    output_b(condition);
    condition=condition<<1;
    delay_ms(100);
    }
    
    
    
}
}  
 //output_high(LED1_PIN);
